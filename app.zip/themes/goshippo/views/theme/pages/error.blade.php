<html>
    <head></head>
    <body style="font-size: 1.125rem;background-color: #1a202c;color: #a0aec0;text-transform: uppercase;display: flex;align-items: center;justify-content: center;">
        {{$message}}
    </body>
</html>