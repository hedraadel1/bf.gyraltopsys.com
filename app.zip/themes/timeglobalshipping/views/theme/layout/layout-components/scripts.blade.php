  <script src="{{ asset('themes/timeglobalshipping/vendors/js/jquery-3.6.0.min.js') }}"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
  <script src="{{ asset('themes/timeglobalshipping/vendors/js/bootstrap.bundle.min.js') }}"></script>
  <script src="{{ asset('themes/timeglobalshipping/assets/js/main.js') }}"></script>

  <!-- scripts -->
  <script type="text/javascript" src="{{ asset('themes/html/assets/js/functions.js') }}"></script>
  <script src="{{ asset('themes/easyship/assets/js/main.js') }}"></script>
  <script type="text/javascript" src="{{ asset('themes/html/assets/js/feather.min.js') }}"></script>
<script>
    feather.replace();
</script>