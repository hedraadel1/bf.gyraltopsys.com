<!-- scripts -->
  <script src="{{ asset('themes/flextock/assets/js/main.js') }}"></script>

  <!-- Bottom script -->
<script type="text/javascript" src="{{ asset('themes/html/assets/js/jquery.slim.min.js') }}" ></script>
<script type="text/javascript" src="{{ asset('themes/html/assets/js/bootstrap.bundle.min.js') }}"  ></script>

<script type="text/javascript" src="{{ asset('themes/html/assets/js/functions.js') }}"></script>
<script src="{{ asset('themes/easyship/assets/js/main.js') }}"></script>
<script type="text/javascript" src="{{ asset('themes/html/assets/js/feather.min.js') }}"></script>
<script>
    feather.replace();
</script>